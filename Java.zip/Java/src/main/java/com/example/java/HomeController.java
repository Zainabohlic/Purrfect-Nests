package com.example.java;

public class HomeController {
}
